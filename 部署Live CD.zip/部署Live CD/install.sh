#!/bin/bash
toilet Install!
echo ""
echo "挂载 Live CD"
sudo umount /media/livecd/cdrom > /dev/null
sudo mkdir /media/livecd/cdrom > /dev/null
echo "光驱列表："
echo /dev/sr*
echo "请输入此 Live CD 所在的光驱或者此 Live CD ISO 文件所在目录"
# 获取输入内容
read -p "" input
sudo mount $input /media/livecd/cdrom
#sudo mount /media/livecd/cdrom
echo "按下回车键打开磁盘分区工具 GParted 进行分区操作（如果不需要则打开后立即关闭即可）"
read -p "按下回车进行下一步操作……"
gparted
echo "到时候询问需要 squashfs 的文件请输入：/media/livecd/cdrom/live/filesystem.squashfs"
echo "提示：lub 的 Grub 修复可能会有问题，后面会有专门的程序修复引导"
read -p "按下回车进行下一步操作……"
sudo lub -r
echo "正在释放一些所需程序"
sudo cp setsudo.py /tmp/target/usr/bin/setsudo.py
sudo cp livecd-installer.sh /tmp/target/usr/bin/livecd-installer
sudo cp livecd-installer.desktop /tmp/target/usr/share/applications/livecd-installer.desktop
sudo chmod 777 /tmp/target/usr/bin/setsudo.py
sudo chmod 777 /tmp/target/usr/bin/livecd-installer
echo "按下回车键打开 Pardus Boot Repair 以便修复系统引导"
read -p "按下回车进行下一步操作……"
pardus-boot-repair
echo "第一部分部署完毕！按下回车键重启 Live CD，如果不想重启，直接关闭本终端即可！"
echo "提示：如果想要进行下一步的部署，请登录您的用户然后在启动器找到“第二部分部署”并打开即可"
read -p "按下回车重启进行下一步操作……"